var db = connect('localhost', 27017)
    PhillyEagles = null;

print('* Creating Eagles Database');

db.names.insert({'Quarterback' : 'Carson Wentz'});
db.names.insert({'Runningback' : 'Miles Sanders'});
db.names.insert({'Widereceiver' : 'Alshon Jeffery'});
db.names.insert({'Tightend' : 'Zack Ertz'});

print(' * Positions created');

PhillyEagles = db.names.find();

print('* All positions: ');

while(PhillyEagles.hasNext()){
  printjson(PhillyEagles.next());
}

db.names.find().forEach( function(thisDoc) {
  if(thisDoc.name === 'Carson Wentz')
});
  
print(' * All positions');

db.dropDatabase();
  
print('* Positions erased');  